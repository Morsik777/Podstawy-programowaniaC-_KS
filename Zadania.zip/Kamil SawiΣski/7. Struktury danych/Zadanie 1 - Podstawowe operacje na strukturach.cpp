#include <iostream>
#include <string>
using namespace std;

struct Osoba {
    string imie;
    string nazwisko;
    int wiek;
};

int main() {
    Osoba osoba = {"Jan", "Kowalski", 25};

    cout << "Dane przed modyfikacja:\n";
    cout << "Imie: " << osoba.imie << ", Nazwisko: " << osoba.nazwisko << ", Wiek: " << osoba.wiek << endl;

    osoba.wiek = 30;

    cout << "\nDane po modyfikacji:\n";
    cout << "Imie: " << osoba.imie << ", Nazwisko: " << osoba.nazwisko << ", Wiek: " << osoba.wiek << endl;

    return 0;
}