#include <iostream>
#include <string>
using namespace std;

string GetTextFromUser() {
    string text;
    cout << "Podaj ciag znakow: ";
    getline(cin, text);
    return text;
}

string ReverseString(string text) {
    int n = text.length();

    for (int i = 0; i < n / 2; i++) {
        char temp = text[i];
        text[i] = text[n - 1 - i];
        text[n - 1 - i] = temp;
    }

    return text;
}

void DisplayResult(string text) {
    cout << "Odwrocony ciag: " << text;
}

int main() {
    string text = GetTextFromUser();
    string reversedText = ReverseString(text);
    DisplayResult(reversedText);

    return 0;
}