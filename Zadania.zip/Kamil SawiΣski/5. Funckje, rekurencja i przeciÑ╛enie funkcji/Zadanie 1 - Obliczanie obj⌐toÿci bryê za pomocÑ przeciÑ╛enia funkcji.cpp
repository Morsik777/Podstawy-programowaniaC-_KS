#include <iostream>
using namespace std;

double CalculateVolume(double a) {
    return a * a * a;
}

double CalculateVolume(double a, double b, double h) {
    return a * b * h;
}

double CalculateVolume(double r, double h, bool cylinder) {
    return 3.1415 * r * r * h;
}

void DisplayResult(double v) {
    cout << "Objetosc wynosi: " << v;
}

int main() {
    int choice;
    cout << "Wybierz bryle do obliczenia objetosci:\n";
    cout << "1 - Szescian (V = a^3)\n";
    cout << "2 - Prostopadloscian (V = a * b * h)\n";
    cout << "3 - Walec (V = pi * r^2 * h)\n";
    cout << "Wybierz numer bryly: ";
    cin >> choice;

    if (choice == 1) {
        double a;
        cin >> a;
        DisplayResult(CalculateVolume(a));
    } else if (choice == 2) {
        double a, b, h;
        cin >> a >> b >> h;
        DisplayResult(CalculateVolume(a, b, h));
    } else if (choice == 3) {
        double r, h;
        cin >> r >> h;
        DisplayResult(CalculateVolume(r, h, true));
    }

    return 0;
}