#include <iostream>
using namespace std;

int GetNumberFromUser() {
    int liczba;
    cout << "Podaj liczbe: ";
    cin >> liczba;
    return liczba;
}

long long CalculateFactorial(int liczba) {
    long long silnia = 1;

    for (int i = 1; i <= liczba; i++) {
        silnia *= i;
    }

    return silnia;
}

void DisplayResult(int liczba, long long silnia) {
    cout << "Silnia liczby " << liczba << " wynosi: " << silnia;
}

int main() {
    int liczba = GetNumberFromUser();
    long long silnia = CalculateFactorial(liczba);

    DisplayResult(liczba, silnia);

    return 0;
}