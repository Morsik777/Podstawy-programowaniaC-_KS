#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

void LosujTablice(int *tab, int rozmiar, int poczatek, int koniec) {
    for (int i = 0; i < rozmiar; i++) {
        tab[i] = poczatek + rand() % (koniec - poczatek + 1);
    }
}

bool SprawdzLiczbe(int *liczba, int *tab, int rozmiar) {
    for (int i = 0; i < rozmiar; i++) {
        if (tab[i] == *liczba) {
            return true;
        }
    }
    return false;
}

int main() {
    srand(time(0));

    int ile, poczatek, koniec;

    cout << "Ile liczb wylosowac: ";
    cin >> ile;

    cout << "Wartosc poczatkowa: ";
    cin >> poczatek;

    cout << "Wartosc koncowa: ";
    cin >> koniec;

    int *tab = new int[ile];

    LosujTablice(tab, ile, poczatek, koniec);

    cout << "Tablica: ";
    for (int i = 0; i < ile; i++) {
        cout << tab[i] << ", ";
    }
    cout << endl;

    int liczba, proby = 0;

    do {
        cout << "\nPodaj liczbe: ";
        cin >> liczba;
        proby++;

        if (SprawdzLiczbe(&liczba, tab, ile)) {
            cout << "Zgadles!\n";
            cout << "Zgadles za " << proby << " razem.\n";
            break;
        } else {
            cout << "Nie zgadles\n";
        }
    } while (true);

    delete[] tab;

    return 0;
}