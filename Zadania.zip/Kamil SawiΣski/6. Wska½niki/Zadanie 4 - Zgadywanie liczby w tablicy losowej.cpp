#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

void LosujTablice(int *tab, int rozmiar) {
    for (int i = 0; i < rozmiar; i++) {
        tab[i] = rand() % 51;
    }
}

bool SprawdzLiczbe(int *liczba, int *tab, int rozmiar) {
    for (int i = 0; i < rozmiar; i++) {
        if (tab[i] == *liczba) {
            return true;
        }
    }
    return false;
}

int main() {
    srand(time(0));

    int tab[10];
    LosujTablice(tab, 10);

    cout << "Tablica: ";
    for (int i = 0; i < 10; i++) {
        cout << tab[i] << ", ";
    }
    cout << endl;

    int liczba, proby = 0;

    do {
        cout << "Podaj liczbe: ";
        cin >> liczba;
        proby++;

        if (SprawdzLiczbe(&liczba, tab, 10)) {
            cout << "Zgadles!\n";
            cout << "Zgadles za " << proby << " razem.\n";
            break;
        } else {
            cout << "Nie zgadles\n";
        }
    } while (true);

    return 0;
}