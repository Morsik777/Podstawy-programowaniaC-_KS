#include <iostream>

int main() {
    int tab[2][3];
    int trans[3][2];

    std::cout << "Podaj 6 liczb calkowitych do macierzy 2x3:\n";

    for (int i = 0; i < 2; i++) {
        for (int j = 0; j < 3; j++) {
            std::cout << "Podaj liczbe dla wiersza " << i + 1
                      << ", kolumny " << j + 1 << ": ";
            std::cin >> tab[i][j];
        }
    }

    for (int i = 0; i < 2; i++) {
        for (int j = 0; j < 3; j++) {
            trans[j][i] = tab[i][j];
        }
    }

    std::cout << "\nTransponowana macierz:\n";

    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 2; j++) {
            std::cout << trans[i][j] << " ";
        }
        std::cout << std::endl;
    }

    return 0;
}