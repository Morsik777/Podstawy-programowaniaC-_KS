#include <iostream>

int main() {
    int tab[10];

    std::cout << "Podaj 10 liczb calkowitych:\n";

    for (int i = 0; i < 10; i++) {
        std::cout << "Podaj liczbe nr " << i + 1 << ": ";
        std::cin >> tab[i];
    }

    int min = tab[0];

    for (int i = 1; i < 10; i++) {
        if (tab[i] < min) {
            min = tab[i];
        }
    }

    std::cout << "Najmniejsza liczba to: " << min << std::endl;

    return 0;
}