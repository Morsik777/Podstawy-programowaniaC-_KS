#include <iostream>

int main() {
    int tab[5];
    int suma = 0;

    for (int i = 0; i < 5; i++) {
        std::cout << "Podaj liczbe nr " << i + 1 << ": ";
        std::cin >> tab[i];
        suma += tab[i];
    }

    std::cout << "Srednia liczb: " << suma / 5.0 << std::endl;

    return 0;
}