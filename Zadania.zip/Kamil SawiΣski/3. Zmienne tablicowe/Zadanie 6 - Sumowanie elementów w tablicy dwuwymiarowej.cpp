#include <iostream>

int main() {
    int tab[3][3];
    int suma = 0;

    std::cout << "Podaj 9 liczb calkowitych do macierzy 3x3:\n";

    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            std::cout << "Podaj liczbe dla wiersza " << i + 1
                      << ", kolumny " << j + 1 << ": ";
            std::cin >> tab[i][j];
            suma += tab[i][j];
        }
    }

    std::cout << "\nSuma elementow macierzy: " << suma << std::endl;

    return 0;
}