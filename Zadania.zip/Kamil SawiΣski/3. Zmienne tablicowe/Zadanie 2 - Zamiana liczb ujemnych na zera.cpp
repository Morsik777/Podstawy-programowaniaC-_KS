#include <iostream>

int main() {
    int tab[5];

    std::cout << "Wprowadz 5 liczb calkowitych:\n";

    for (int i = 0; i < 5; i++) {
        std::cin >> tab[i];
    }

    for (int i = 0; i < 5; i++) {
        if (tab[i] < 0) {
            tab[i] = 0;
        }
    }

    std::cout << "Liczby ujemne zamienione na 0: ";

    for (int i = 0; i < 5; i++) {
        std::cout << tab[i];
        if (i < 4) {
            std::cout << ", ";
        }
    }

    return 0;
}