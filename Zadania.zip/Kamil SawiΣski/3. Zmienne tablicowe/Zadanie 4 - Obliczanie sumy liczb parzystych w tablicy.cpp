#include <iostream>

int main() {
    int tab[10];
    int suma = 0;

    for (int i = 0; i < 10; i++) {
        std::cout << "Podaj liczbe nr " << i + 1 << ": ";
        std::cin >> tab[i];
    }

    std::cout << "Liczby parzyste: ";

    for (int i = 0; i < 10; i++) {
        if (tab[i] % 2 == 0) {
            std::cout << tab[i] << ", ";
            suma += tab[i];
        }
    }

    std::cout << "\nSuma liczb parzystych: " << suma << std::endl;

    return 0;
}