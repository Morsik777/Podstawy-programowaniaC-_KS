#include <iostream>

int main() {
    int szerokosc, wysokosc;

    std::cout << "Podaj szerokosc: ";
    std::cin >> szerokosc;

    std::cout << "Podaj wysokosc: ";
    std::cin >> wysokosc;

    std::cout << std::endl;

    for (int i = 0; i < wysokosc; i++) {
        for (int j = 0; j < i; j++) {
            std::cout << " ";
        }

        for (int j = 0; j < szerokosc - 2 * i; j++) {
            std::cout << "*";
        }

        std::cout << std::endl;
    }

    return 0;
}