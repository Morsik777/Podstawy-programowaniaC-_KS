#include <iostream>

int main() {
    int N, licznik = 0, i = 1;

    std::cout << "Podaj liczbe calkowita dodatnia N: ";
    std::cin >> N;

    do {
        if (i % 2 == 0) {
            licznik++;
        }
        i++;
    } while (i <= N);

    std::cout << "Liczba liczb parzystych od 1 do " << N
              << " wynosi: " << licznik << std::endl;

    return 0;
}