#include <iostream>

int main() {
    int liczba;
    char wybor;

    do {
        std::cout << "Podaj liczbe: ";
        std::cin >> liczba;

        std::cout << "Wprowadziles liczbe: " << liczba << std::endl;

        std::cout << "Czy chcesz wprowadzic kolejna liczbe? (t/n): ";
        std::cin >> wybor;

    } while (wybor == 't');

    std::cout << "Dziekuje za wprowadzenie liczb!" << std::endl;

    return 0;
}