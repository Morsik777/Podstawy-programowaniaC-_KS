#include <iostream>

int main() {
    int N, i = 2;

    std::cout << "Podaj liczbe N: ";
    std::cin >> N;

    std::cout << "\nLiczby parzyste od 2 do " << N << ":\n";

    while (i <= N) {
        std::cout << i << std::endl;
        i += 2;
    }

    return 0;
}