#include <iostream>

int main() {
    int N, suma = 0, i = 1;

    std::cout << "Podaj liczbe N: ";
    std::cin >> N;

    while (i <= N) {
        suma += i;
        i++;
    }

    std::cout << "\nSuma liczb naturalnych do " << N << ": " << suma << std::endl;

    return 0;
}