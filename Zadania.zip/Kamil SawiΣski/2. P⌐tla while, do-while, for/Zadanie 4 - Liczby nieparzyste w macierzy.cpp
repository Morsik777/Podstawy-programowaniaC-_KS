#include <iostream>

int main() {
    int wiersze, kolumny;
    int liczba = 1;

    std::cout << "Podaj liczbe wierszy: ";
    std::cin >> wiersze;

    std::cout << "Podaj liczbe kolumn: ";
    std::cin >> kolumny;

    std::cout << std::endl;

    for (int i = 0; i < wiersze; i++) {
        for (int j = 0; j < kolumny; j++) {
            std::cout << liczba << "\t";
            liczba += 2;
        }
        std::cout << std::endl;
    }

    return 0;
}