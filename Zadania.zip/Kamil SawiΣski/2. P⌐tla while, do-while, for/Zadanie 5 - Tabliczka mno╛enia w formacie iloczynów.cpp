#include <iostream>

int main() {
    int N;

    std::cout << "Podaj liczbe N: ";
    std::cin >> N;

    std::cout << std::endl;

    for (int i = 1; i <= N; i++) {
        for (int j = 1; j <= N; j++) {
            std::cout << i << " * " << j << " = " << i * j << std::endl;
        }
        std::cout << std::endl;
    }

    return 0;
}