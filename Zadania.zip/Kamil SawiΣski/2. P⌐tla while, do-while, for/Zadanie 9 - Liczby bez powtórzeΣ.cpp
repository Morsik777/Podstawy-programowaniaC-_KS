#include <iostream>

int main() {
    int licznik = 0;

    for (int setki = 1; setki <= 9; setki++) {
        for (int dziesiatki = 0; dziesiatki <= 9; dziesiatki++) {
            for (int jednosci = 0; jednosci <= 9; jednosci++) {
                if (setki != dziesiatki &&
                    setki != jednosci &&
                    dziesiatki != jednosci) {

                    std::cout << setki * 100 + dziesiatki * 10 + jednosci << std::endl;
                    licznik++;
                }
            }
        }
    }

    std::cout << "Liczb bez powtarzajacych sie cyfr: " << licznik << std::endl;

    return 0;
}