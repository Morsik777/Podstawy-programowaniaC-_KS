#include <iostream>

int main() {
    int N, suma = 0;

    std::cout << "Podaj liczbe N: ";
    std::cin >> N;

    for (int i = 1; i <= N; i++) {
        suma += i;
    }

    std::cout << "\nSuma liczb od 1 do " << N << " wynosi: " << suma << std::endl;

    return 0;
}