int main() {
    int liczbaCalkowita = 10;
    float liczbaZmiennoprzecinkowa = 3.14f;
    char znak = 'A';
    bool wartoscLogiczna = true;

    std::cout << "Zmienna calkowita: " << liczbaCalkowita << std::endl;
    std::cout << "Zmienna zmiennoprzecinkowa: " << liczbaZmiennoprzecinkowa << std::endl;
    std::cout << "Zmienna znakowa: " << znak << std::endl;
    std::cout << "Zmienna logiczna: " << std::boolalpha << wartoscLogiczna << std::endl;

    return 0;
}