#include <iostream>

int main() {
    char tekst[21];

    std::cout << "Podaj ciag znakow (max 20 znakow): ";
    std::cin.getline(tekst, 21);

    for (int i = 0; tekst[i] != '\0'; i++) {
        if (tekst[i] == 'a') {
            tekst[i] = 'o';
        }
    }

    std::cout << "Zmodyfikowany ciag znakow: " << tekst << std::endl;

    return 0;
}