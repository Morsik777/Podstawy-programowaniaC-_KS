#include <iostream>

int main() {
    char tekst[21];

    std::cout << "Podaj ciag znakow (max 20 znakow): ";
    std::cin.getline(tekst, 21);

    std::cout << "Wprowadzony ciag znakow: " << tekst << std::endl;

    return 0;
}