#include <iostream>

int main() {
    char tekst[100];
    char znak;
    int licznik = 0;

    std::cout << "Podaj ciag znakow: ";
    std::cin.getline(tekst, 100);

    std::cout << "Podaj znak do zliczenia: ";
    std::cin >> znak;

    std::cout << "Pozycje wystapien: ";

    bool pierwsza = true;

    for (int i = 0; tekst[i] != '\0'; i++) {
        if (tekst[i] == znak) {
            licznik++;

            if (!pierwsza) {
                std::cout << ", ";
            }

            std::cout << i;
            pierwsza = false;
        }
    }

    std::cout << std::endl;
    std::cout << "Liczba wystapien znaku '" << znak << "': " << licznik << std::endl;

    return 0;
}