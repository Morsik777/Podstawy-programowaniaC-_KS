#include <iostream>
#include <cstring>

int main() {
    char tekst[100];
    char odwrocony[100];

    std::cout << "Podaj ciag znakow: ";
    std::cin.getline(tekst, 100);

    int dlugosc = strlen(tekst);

    for (int i = 0; i < dlugosc; i++) {
        odwrocony[i] = tekst[dlugosc - 1 - i];
    }

    odwrocony[dlugosc] = '\0';

    std::cout << "Odwrocony ciag: " << odwrocony << std::endl;

    return 0;
}